import java.awt.*;
public class Car {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Frame f = new Frame("Car");
		
		f.setTitle( f.getTitle() + "frame");
		f.setLocation(500, 250);
		f.setSize(300, 300);
		f.setVisible(true);
	}

}
