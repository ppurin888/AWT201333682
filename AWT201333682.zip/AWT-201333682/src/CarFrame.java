import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

public class CarFrame extends Frame implements WindowListener {
// CarFrame -> �̺�Ʈ �ҽ�
   public CarFrame(){
      
   //   this.addWindowListener(new MyWindowListener()); // 1�� ���
   //   this.addWindowListener(new MyWindowListener2()); // 2�� ���
   //   addWindowListener(this);   // 3�� ���
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e){
            System.exit(0);
         }
      });
    
      setSize(400, 600);
      setVisible(true);
 
   } 
   class MyWindowListener implements WindowListener {

      @Override
      public void windowActivated(WindowEvent e) {
         // TODO Auto-generated method stub
         
      }

      @Override
      public void windowClosed(WindowEvent e) {
         // TODO Auto-generated method stub
   
      }

      @Override
      public void windowClosing(WindowEvent e) {
         // TODO Auto-generated method stub
      System.exit(0);
      }

      @Override
      public void windowDeactivated(WindowEvent e) {
         // TODO Auto-generated method stub
         
      }

      @Override
      public void windowDeiconified(WindowEvent e) {
         // TODO Auto-generated method stub
         
      }

      @Override
      public void windowIconified(WindowEvent e) {
         // TODO Auto-generated method stub
         
      }

      @Override
      public void windowOpened(WindowEvent e) {
         // TODO Auto-generated method stub
         
      }
      
   }
   
   class MyWindowListener2 extends WindowAdapter {
      // �̺�Ʈ �ڵ鷯 - ���� �ñ׳���
      // ����Ÿ���� ����       
      public void windowClosing(WindowEvent e){
         System.exit(0);
      }
   }

   @Override
   public void windowActivated(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void windowClosed(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void windowClosing(WindowEvent e) {
      System.exit(0);
      
   }

   @Override
   public void windowDeactivated(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void windowDeiconified(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void windowIconified(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }

   @Override
   public void windowOpened(WindowEvent e) {
      // TODO Auto-generated method stub
      
   }
}